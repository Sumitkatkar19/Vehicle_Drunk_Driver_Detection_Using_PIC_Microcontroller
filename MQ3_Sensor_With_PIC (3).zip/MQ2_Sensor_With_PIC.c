#include <p18f4550.h> //Include Controller specific .h
//Configuration bit settings
#pragma config FOSC = HS //Oscillator Selection
#pragma config WDT = OFF //Disable Watchdog timer
#pragma config LVP = OFF //Disable Low Voltage Programming
#pragma config PBADEN = OFF //Disable PORTB Analog inputs
//Declarations
#define MQ2_Sensor PORTBbits.RB4 //SW0 interfaced to RB4
#define Buzzer PORTCbits.RC2 //Relay interfaced to RC1
//Function Prototypes
void msdelay (unsigned int time);//Function for delay
//Start of Program Code
void main() //Main Program
{
	INTCON2bits.RBPU=0; //To Activate the internal pull on PORTB
	TRISBbits.TRISB4=1; //To configure RB4 as input for sensing SW0
	TRISCbits.TRISC2=0; //To configure RC2 (Buzzer) as output
	Buzzer = 0; //Initial Value for Relay
	while (1) //While loop for repeated operation
	{
		if (MQ2_Sensor) //To check whether SW0 is pressed
		{
			Buzzer = 1;
		}
		else
		{
			Buzzer = 0;
		}
	}

} //End of the Program
//Function Definitions
void msdelay (unsigned int time)//Function for delay
{
	unsigned int i, j;
	for (i = 0; i < time; i++)
	for (j = 0; j < 275; j++); //Calibrated for a 1 ms delay in MPLAB
}